# AI Job Search Assistant

## Project Overview
AI Job Search Assistant is a comprehensive web application that helps users search for job opportunities, analyze their resumes, get company insights, and track job applications. The system fetches real-time job listings using a job search API, provides intelligent job matching based on resume skills, and offers company research tools.

## Features
- **Automatic Job Matching**: Upload resume and get instant personalized job recommendations
- **Resume Analysis**: Upload PDF resume for skill extraction and experience analysis
- **Intelligent Job Search**: Search jobs by keyword and location with intelligent matching
- **Company Insights**: Get company ratings, reviews, and information
- **Application Tracker**: Save and track job applications with status updates
- **Skill-Based Recommendations**: Jobs automatically sorted by relevance to your resume skills
- **Database Integration**: SQLite database for storing job applications

## Technologies Used
- Python
- Streamlit
- Requests
- BeautifulSoup4
- PDFPlumber
- SQLite
- JSearch API (RapidAPI)

## Project Structure
```
job-search-ai-agent/
│
├── app.py                 # Main Streamlit application
├── job_api.py            # Job search API integration
├── resume_parser.py      # Resume PDF parsing and analysis
├── company_info.py       # Company information scraping
├── job_matching.py       # Job-resume matching algorithm
├── database.py           # SQLite database operations
├── requirements.txt      # Python dependencies
└── README.md            # Project documentation
```

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd job-search-ai-agent
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Set up API key:
   - Get API key from [RapidAPI JSearch](https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch)
   - Update `API_KEY` in `job_api.py`

## Usage

1. Run the application:
   ```bash
   streamlit run app.py
   ```

2. Open your browser to the provided local URL

3. **Upload your resume (PDF) in the sidebar** - The system will automatically:
   - Extract your skills and experience
   - Search for relevant jobs based on your skills
   - Show personalized job recommendations

4. Use the tabs to:
   - **Job Search**: View auto-matched jobs and search manually
   - **Resume Analysis**: Review your resume analysis and top matches
   - **Company Insights**: Research companies by name
   - **Application Tracker**: Manage saved jobs and track status

## How Automatic Job Search Works

1. **Resume Upload**: Upload your PDF resume
2. **Skill Extraction**: System identifies your technical skills
3. **Auto Search**: Searches multiple job sites using your top skills
4. **Matching**: Calculates match percentage for each job
5. **Ranking**: Sorts jobs by relevance to your profile
6. **Recommendations**: Displays top 20 most relevant opportunities

## Deployment

Deploy on Streamlit Cloud:
1. Push code to GitHub
2. Connect to Streamlit Cloud
3. Deploy from your repository

## API Keys Required

- **JSearch API**: For job search functionality
- Get from RapidAPI marketplace

## Features in Detail

### Job Search
- Real-time job listings from multiple sources
- Location-based filtering
- Salary information
- Direct application links

### Resume Analysis
- PDF text extraction
- Skill identification
- Experience calculation
- Resume preview

### Company Research
- Company ratings and reviews
- Basic company information
- Web scraping integration

### Application Tracking
- Save interesting jobs
- Track application status
- Organized job management

### Job Matching
- Skill-based matching algorithm
- Match percentage calculation
- Sorted job recommendations

## Database Schema

### Applications Table
- id (Primary Key)
- job_title
- company
- location
- salary
- status (saved/applied/interview/rejected/accepted)
- applied_date

### User Preferences Table
- id (Primary Key)
- preference_key
- preference_value
- created_date

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.  

## Installation

Clone the repository:
