def calculate_match_score(resume_skills, job_title):

    job_title = job_title.lower().split()

    matched = 0

    for skill in resume_skills:
        if skill in job_title:
            matched += 1

    if len(resume_skills) == 0:
        return 0

    score = (matched / len(resume_skills)) * 100

    return round(score)


def find_missing_skills(resume_skills, job_title):

    job_words = job_title.lower().split()

    missing = []

    for skill in resume_skills:
        if skill not in job_words:
            missing.append(skill)

    return missing