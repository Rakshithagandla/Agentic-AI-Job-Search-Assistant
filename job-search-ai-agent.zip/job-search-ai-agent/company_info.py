import requests
from bs4 import BeautifulSoup

def get_company_info(company_name):

    # Dummy insights (safe for demo)
    return {
        "rating": "4.2 ⭐",
        "size": "1000+ employees",
        "industry": "IT Services",
        "about": f"{company_name} is a growing tech company."
    }