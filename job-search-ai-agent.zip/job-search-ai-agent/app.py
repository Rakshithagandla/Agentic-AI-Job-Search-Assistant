import streamlit as st
from job_api import search_jobs
from resume_parser import extract_resume_text, extract_skills, extract_experience
from company_info import get_company_info
from job_matching import calculate_match_score, find_missing_skills
from database import save_job, get_saved_jobs

# Page configuration
st.set_page_config(
    page_title="AI Job Search Assistant",
    page_icon="💼",
    layout="wide"
)

# Custom CSS for job cards
st.markdown("""
<style>
.job-card {
    background-color: #f5f7ff;
    padding: 20px;
    border-radius: 10px;
    border: 1px solid #ddd;
    margin-bottom: 15px;
}
.title {
    text-align: center;
}
</style>
""", unsafe_allow_html=True)

def auto_job_search(skills, experience_years=0):
    """
    Automatically search for jobs based on resume skills
    """
    if not skills:
        return []
    
    # Use top 2-3 skills for search
    top_skills = skills[:3]
    
    # Create search queries combining skills
    search_queries = []
    
    # Single skill searches
    for skill in top_skills:
        search_queries.append(skill)
    
    # Combined skill searches
    if len(top_skills) >= 2:
        search_queries.append(f"{top_skills[0]} {top_skills[1]}")
    if len(top_skills) >= 3:
        search_queries.append(f"{top_skills[0]} {top_skills[1]} {top_skills[2]}")
    
    # Add experience-based keywords
    if experience_years > 3:
        search_queries.extend([f"Senior {skill}" for skill in top_skills[:2]])
    elif experience_years > 1:
        search_queries.extend([f"Junior {skill}" for skill in top_skills[:2]])
    
    # Search for jobs using the queries
    all_jobs = []
    locations = ["Hyderabad", "Bangalore", "Mumbai", "Delhi", "Chennai"]
    
    for query in search_queries[:5]:  # Limit to 5 queries to avoid API limits
        for location in locations[:2]:  # Search in 2 locations
            try:
                jobs = search_jobs(query, location)
                all_jobs.extend(jobs)
            except:
                continue
    
    # Remove duplicates based on job title and company
    seen = set()
    unique_jobs = []
    for job in all_jobs:
        key = (job.get('title', '').lower(), job.get('company', '').lower())
        if key not in seen:
            seen.add(key)
            unique_jobs.append(job)
    
    # Sort by relevance using job matching
    if unique_jobs:
        for job in unique_jobs:
            job['match_score'] = calculate_match_score(skills, job['title'])
        unique_jobs.sort(key=lambda x: x['match_score'], reverse=True)
    
    return unique_jobs  # Return all unique jobs found

# Initialize session state
if 'resume_text' not in st.session_state:
    st.session_state.resume_text = ""
if 'resume_skills' not in st.session_state:
    st.session_state.resume_skills = []
if 'skills' not in st.session_state:
    st.session_state.skills = []
if 'resume_experience' not in st.session_state:
    st.session_state.resume_experience = 0
if 'auto_jobs' not in st.session_state:
    st.session_state.auto_jobs = []
if 'auto_search_done' not in st.session_state:
    st.session_state.auto_search_done = False

# Title
st.markdown("<h1 class='title'>AI Job Search Assistant</h1>", unsafe_allow_html=True)
st.write("Find the latest job opportunities quickly and easily.")

# Tab navigation state
if 'active_tab' not in st.session_state:
    st.session_state.active_tab = 0

tab1, tab2, tab3, tab4 = st.tabs([
    "🔍 Job Search",
    "📄 Resume Analysis",
    "🏢 Company Insights",
    "📊 Saved Jobs"
])

# Resume Upload Section (available in all tabs)
with st.sidebar:
    st.header("Resume Upload")
    uploaded_file = st.file_uploader("Upload your resume (PDF)", type="pdf")
    if uploaded_file is not None:
        if st.button("Analyze Resume"):
            with st.spinner("Analyzing resume..."):
                st.session_state.resume_text = extract_resume_text(uploaded_file)
                st.session_state.resume_skills = extract_skills(st.session_state.resume_text)
                st.session_state.skills = st.session_state.resume_skills
                st.session_state.resume_experience = extract_experience(st.session_state.resume_text)
            
            st.success("Resume analyzed successfully!")
            st.write(f"**Skills Found:** {', '.join(st.session_state.resume_skills)}")
            st.write(f"**Experience:** {st.session_state.resume_experience} years")
            
            # Automatically search for relevant jobs
            if st.session_state.skills:
                with st.spinner("Finding relevant jobs based on your skills..."):
                    st.session_state.auto_jobs = auto_job_search(
                        st.session_state.skills, 
                        st.session_state.resume_experience
                    )
                    st.session_state.auto_search_done = True
                
                if st.session_state.auto_jobs:
                    st.success(f"Found {len(st.session_state.auto_jobs)} relevant job opportunities!")
                    st.info("Check the 'Job Search' tab to see personalized recommendations.")
                else:
                    st.warning("No jobs found matching your skills. Try manual search.")
    
    # Auto job search button
    if st.session_state.resume_skills and st.button("🔄 Refresh Job Suggestions"):
        with st.spinner("Finding updated job matches..."):
            st.session_state.auto_jobs = auto_job_search(
                st.session_state.resume_skills, 
                st.session_state.resume_experience
            )
            st.session_state.auto_search_done = True
        st.success(f"Updated job suggestions! Found {len(st.session_state.auto_jobs)} matches.")

    # Indicate auto-search status in sidebar only
    if st.session_state.auto_search_done and st.session_state.auto_jobs:
        st.info(f"Found {len(st.session_state.auto_jobs)} jobs that match your skills: {', '.join(st.session_state.skills)}")
    elif st.session_state.auto_search_done:
        st.warning("No job matches found yet. Try refresh or adjust your resume skills.")

# Tab 1: Job Search
with tab1:
    st.header("Job Search")
    
    if st.session_state.auto_search_done and st.session_state.auto_jobs:
        st.subheader("🎯 Jobs Matched to Your Resume")
        st.info(f"Showing {len(st.session_state.auto_jobs)} jobs matched to your resume")
        for i, job in enumerate(st.session_state.auto_jobs):
            match_info = f" | Match: {job.get('match_score', 0)}%"
            st.markdown(f"""
            <div class="job-card">
                <h3>{job['title']}{match_info}</h3>
                <p><b>Company:</b> {job['company']}</p>
                <p><b>Location:</b> {job['location']}</p>
                <p><b>Salary:</b> {job['salary']}</p>
            </div>
            """, unsafe_allow_html=True)
            colA, colB = st.columns(2)
            with colA:
                if st.button("Save Job", key=f"auto_save_{i}"):
                    save_job(job)
                    st.success("Job saved!")
            with colB:
                if st.button("Apply Now", key=f"auto_apply_{i}"):
                    st.markdown(f"[Apply Here]({job.get('job_apply_link', '#')})")
        st.markdown("---")

    st.subheader("🔍 Manual Search")
    col1, col2 = st.columns(2)
    with col1:
        keyword = st.text_input("Enter Job Role", "Python Developer")
    with col2:
        location = st.selectbox("Select Location", ["Hyderabad", "Bangalore", "Mumbai", "Delhi", "Chennai"])

    if st.button("Search Jobs"):
        query = " ".join(st.session_state.skills[:3]) if st.session_state.skills else keyword
        with st.spinner("Searching for jobs..."):
            jobs = search_jobs(query, location)

        if not jobs:
            st.warning("No jobs found. Try another keyword.")
        else:
            st.success(f"{len(jobs)} jobs found")
            if st.session_state.skills:
                st.info("Jobs displayed with match scores based on your resume")

            for i, job in enumerate(jobs):

                st.markdown(f"""
                <div class="job-card">
                    <h3>{job['title']}</h3>
                    <p>🏢 {job['company']}</p>
                    <p>📍 {job['location']}</p>
                    <p>💰 {job['salary']}</p>
                </div>
                """, unsafe_allow_html=True)

                col1, col2 = st.columns(2)

                with col1:
                    if st.button("Apply", key=job["title"]):
                        st.success("Redirecting...")

                with col2:
                    if st.button("Save Job", key=job["title"] + "_save"):
                        save_job(job)
                        st.success("Job Saved!")

# Tab 2: Resume Analysis
with tab2:
    st.header("Resume Analysis")
    
    if st.session_state.resume_text:
        st.subheader("Resume Summary")
        st.write(f"**Experience:** {st.session_state.resume_experience} years")
        st.write(f"**Skills:** {', '.join(st.session_state.resume_skills)}")
        
        st.subheader("Resume Text Preview")
        st.text_area("Resume Content", st.session_state.resume_text[:1000] + "..." if len(st.session_state.resume_text) > 1000 else st.session_state.resume_text, height=200)
        
        # Show auto-suggested jobs summary
        if st.session_state.auto_search_done and st.session_state.auto_jobs:
            st.subheader("🎯 Top Job Matches")
            st.info(f"Based on your skills, here are the top matching jobs:")
            
            for i, job in enumerate(st.session_state.auto_jobs[:5]):  # Show top 5
                match = job.get('match_score', 0)
                st.write(f"**{i+1}. {job['title']}** at {job['company']} - Match: {match}%")
            
            if st.button("View All Matches", key="view_all_matches"):
                st.session_state.active_tab = 0  # Switch to Job Search tab
                st.rerun()
        
        st.write("### 📈 Suggestions")
        skills = st.session_state.resume_skills
        text = st.session_state.resume_text.lower()
        
        if skills:
            if "python" not in [s.lower() for s in skills]:
                st.write("👉 Learn Python for better opportunities")
            if "sql" not in [s.lower() for s in skills]:
                st.write("👉 Add SQL for database roles")
            if "projects" not in text:
                st.write("👉 Add more projects to your resume")
            if "internship" not in text:
                st.write("👉 Try adding internship experience")
    else:
        st.info("Please upload and analyze your resume in the sidebar to see analysis.")

# Tab 3: Company Insights
with tab3:

    st.header("🏢 Company Insights")

    company_name = st.text_input("Enter Company Name")

    if st.button("Get Info"):

        info = get_company_info(company_name)

        st.write("⭐ Rating:", info["rating"])
        st.write("👥 Size:", info["size"])
        st.write("🏭 Industry:", info["industry"])
        st.write("📄 About:", info["about"])

# Tab 4: Saved Jobs Dashboard
with tab4:

    st.header("📊 Saved Jobs")

    saved_jobs = get_saved_jobs()

    if not saved_jobs:
        st.warning("No saved jobs yet.")
    else:
        for job in saved_jobs:
            st.markdown(f"""
            <div class="job-card">
                <h3>{job[1]}</h3>
                <p>🏢 {job[2]}</p>
                <p>📍 {job[3]}</p>
                <p>💰 {job[4]}</p>
            </div>
            """, unsafe_allow_html=True)