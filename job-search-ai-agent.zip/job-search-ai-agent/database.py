import sqlite3

conn = sqlite3.connect("job_search.db", check_same_thread=False)
c = conn.cursor()

# Create table
c.execute('''
CREATE TABLE IF NOT EXISTS saved_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    company TEXT,
    location TEXT,
    salary TEXT
)
''')

conn.commit()


def save_job(job):
    c.execute("INSERT INTO saved_jobs (title, company, location, salary) VALUES (?, ?, ?, ?)",
              (job["title"], job["company"], job["location"], job["salary"]))
    conn.commit()


def get_saved_jobs():
    c.execute("SELECT * FROM saved_jobs")
    return c.fetchall()