import pdfplumber
import re

def extract_resume_text(file):
    """
    Extract text from PDF resume
    """
    with pdfplumber.open(file) as pdf:
        text = ""
        for page in pdf.pages:
            text += page.extract_text() or ""
    return text

def extract_skills(text):
    """
    Basic skill extraction from resume text
    """
    # Common skills list (can be expanded)
    skills = [
        'python', 'java', 'javascript', 'c++', 'sql', 'html', 'css', 'react', 'node.js',
        'machine learning', 'data analysis', 'aws', 'docker', 'git', 'linux', 'windows'
    ]
    
    found_skills = []
    text_lower = text.lower()
    for skill in skills:
        if skill in text_lower:
            found_skills.append(skill.title())
    
    return found_skills

def extract_experience(text):
    """
    Basic experience extraction (years of experience)
    """
    # Simple regex to find years
    years_pattern = r'(\d+)\s*(?:years?|yrs?)'
    matches = re.findall(years_pattern, text.lower())
    if matches:
        return max([int(y) for y in matches])
    return 0